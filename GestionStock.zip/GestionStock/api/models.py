from django.db import models

# Create your models here.

class Rol(models.Model):
    idRol = models.CharField(max_length=20,null=True)
    nombreRol = models.CharField(max_length=40,null=True)
    descripcionRol =models.CharField(max_length=100,null=True)
    estado = models.BooleanField(default=True,null=True)

    def __str__(self):
        return self.nombreRol

class Usuario(models.Model):
    IdUsuario = models.CharField(max_length=20,null=True)
    IdRolU = models.ForeignKey(Rol,on_delete=models.CASCADE,null=True)
    nombreUsu = models.CharField(max_length=40,null=True)
    DNI_usu = models.CharField(max_length=20,null=True)
    direccionUsu = models.CharField(max_length=40,null=True)
    telefonoUsu = models.CharField(max_length=20,null=True)
    emailUsu = models.CharField(max_length=40,null=True)
    claveUsu = models.CharField(max_length=20,null=True)
    estadoUsu = models.BooleanField(default=True,null=True)

    def __str__(self):
        return self.IdUsuario

class Persona(models.Model):
    IdPersona = models.CharField(max_length=20,null=True)
    Nombre1 = models.CharField(max_length=20,null=True)
    Nombre2 = models.CharField(max_length=20,null=True)
    Apellido1 = models.CharField(max_length=40,null=True)
    Apellido2 = models.CharField(max_length=20,null=True)
    Telefono = models.CharField(max_length=20,null=True)
    Direccion = models.CharField(max_length=40,null=True)

    def __str__(self):
        return self.IdPersona

class Proveedor(models.Model):
    IdProveedor = models.CharField(max_length=80,null=True)
    empresa_proveedor = models.CharField(max_length=80,null=True)
    personaProv = models.ForeignKey(Persona,on_delete=models.CASCADE,null=True)

    def __str__(self):
        return self.IdProveedor

class Cliente(models.Model):
    IdCliente = models.CharField(max_length=20,null=True)
    genero_cliente = models.CharField(max_length=20,null=True)
    IdPersonaC = models.ForeignKey(Persona,on_delete=models.CASCADE,null=True)
    
    def __str__(self):
        return self.IdCliente
    
class Venta(models.Model):
    IdVenta = models.CharField(max_length=20,null=True)
    fecha_venta = models.DateTimeField(null=True)
    hora_venta = models.TimeField(null=True)
    IdClienteV = models.ForeignKey(Cliente,on_delete=models.CASCADE,null=True)
    IdUsuarioV = models.ForeignKey(Usuario,on_delete=models.CASCADE,null=True)

    def __str__(self):
        return self.IdVenta

class Categoria(models.Model):
    IdCategoria = models.CharField(max_length=20,null=True)
    nombreCategoria = models.CharField(max_length=40,null=True)

    def __str__(self):
        return self.IdCategoria

class Producto(models.Model):
    IdProducto = models.CharField(max_length=20,null=True)
    nombre_producto = models.CharField(max_length=40,null=True)
    cantidad_producto = models.IntegerField(null=True)
    precio_compra = models.IntegerField(null=True)
    precio_venta = models.IntegerField(null=True)
    descripcion = models.CharField(max_length=40,null=True)
    IdCategoriaP = models.ForeignKey(Categoria,on_delete=models.CASCADE,null=True)
    IdProveedorP = models.ForeignKey(Proveedor,on_delete=models.CASCADE,null=True)

    def __str__(self):
        return self.IdProducto
    
class DetallesVenta(models.Model):
    IdDVenta = models.CharField(max_length=20,null=True)
    cantidad_venta = models.IntegerField(null=True)
    IdVentaDV = models.ForeignKey(Venta,on_delete=models.CASCADE,null=True)
    IdProductoDV = models.ForeignKey(Producto,on_delete=models.CASCADE,null=True)

    def __str__(self):
        return self.IdDVenta

class Compra(models.Model):
    IdCompra = models.CharField(max_length=20,null=True)
    fecha_compra = models.DateTimeField(null=True)
    hora_compra = models.TimeField(null=True)
    IdUsuarioC = models.ForeignKey(Usuario,on_delete=models.CASCADE,null=True)

    def __str__(self):
        return self.IdCompra

class ProductoCompra(models.Model):
    IdPCompra = models.CharField(max_length=20,null=True)
    cantidad_compra = models.IntegerField(null=True)
    IdCompraPC = models.ForeignKey(Compra,on_delete=models.CASCADE,null=True)
    IdProductoPC = models.ForeignKey(Producto,on_delete=models.CASCADE,null=True)

    def __str__(self):
            return self.IdPCompra

class Presentacion(models.Model):
    IdPresentacion = models.CharField(max_length=20,null=True)
    nombre_Presentacion = models.CharField(max_length=20,null=True)

    def __str__(self):
        return self.IdPresentacion

class ProductoPresentacion(models.Model):
    IdPresentacionPP = models.CharField(max_length=20,null=True)
    medida = models.CharField(max_length=20,null=True)
    IdProductoPP = models.ForeignKey(Producto,on_delete=models.CASCADE,null=True)
    IdPresentacionP = models.ForeignKey(Presentacion,on_delete=models.CASCADE,null=True)

    def __str__(self):
        return self.IdPresentacionPP