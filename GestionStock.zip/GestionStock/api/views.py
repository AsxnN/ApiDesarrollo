from django.shortcuts import render
from rest_framework import viewsets
from . import models,serializers

# Create your views here.

class PersonaViewSet(viewsets.ModelViewSet):
    queryset = models.Persona.objects.all()
    serializer_class = serializers.PersonaSerializer

class ProveedorViewSet(viewsets.ModelViewSet):
    queryset = models.Proveedor.objects.all()
    serializer_class = serializers.ProveedorSerializer

class ClienteViewSet(viewsets.ModelViewSet):
    queryset = models.Cliente.objects.all()
    serializer_class = serializers.ClienteSerializer

class VentaViewSet(viewsets.ModelViewSet):
    queryset = models.Venta.objects.all()
    serializer_class = serializers.VentaSerializer

class CategoriaViewSet(viewsets.ModelViewSet):
    queryset = models.Categoria.objects.all()
    serializer_class = serializers.CategoriaSerializer

class ProductoViewSet(viewsets.ModelViewSet):
    queryset = models.Producto.objects.all()
    serializer_class = serializers.ProductoSerializer

class DetallesVentaViewSet(viewsets.ModelViewSet):
    queryset = models.DetallesVenta.objects.all()
    serializer_class = serializers.DetallesVentaSerializer

class CompraViewSet(viewsets.ModelViewSet):
    queryset = models.Compra.objects.all()
    serializer_class = serializers.CompraSerializer

class ProductoCompraViewSet(viewsets.ModelViewSet):
    queryset = models.ProductoCompra.objects.all()
    serializer_class = serializers.ProductoCompraSerializer

class PresentacionViewSet(viewsets.ModelViewSet):
    queryset = models.Presentacion.objects.all()
    serializer_class = serializers.PresentacionSerializer

class ProductoPresentacionViewSet(viewsets.ModelViewSet):
    queryset = models.ProductoPresentacion.objects.all()
    serializer_class = serializers.ProductoPresentacionSerializer

class RolViewSet(viewsets.ModelViewSet):
    queryset = models.Rol.objects.all()
    serializer_class = serializers.RolSerializer

class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = models.Usuario.objects.all()
    serializer_class = serializers.UsuarioSerializer
