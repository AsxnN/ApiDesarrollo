from rest_framework import serializers
from . import models

class PersonaSerializer(serializers.ModelSerializer):
    nombreCompleto = serializers.SerializerMethodField()

    def get_nombreCompleto(self,obj):
        return f'{obj.Nombre1} {obj.Nombre2}, {obj.Apellido1} {obj.Apellido2}'

    class Meta:
        model = models.Persona
        fields = '__all__'

class ProveedorSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Proveedor
        fields = '__all__'

class ClienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Cliente
        fields = '__all__'

class VentaSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Venta
        fields = '__all__'

class CategoriaSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Categoria
        fields = '__all__'

class ProductoSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Producto
        fields = '__all__'

class DetallesVentaSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.DetallesVenta
        fields = '__all__'

class CompraSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Compra
        fields = '__all__'

class ProductoCompraSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ProductoCompra
        fields = '__all__'

class PresentacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Presentacion
        fields = '__all__'

class ProductoPresentacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ProductoPresentacion
        fields = '__all__'

class RolSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Rol
        fields = '__all__'

class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Usuario
        fields = '__all__'

    