"""
URL configuration for Stock project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from rest_framework.routers import DefaultRouter
from api import views

router = DefaultRouter()
router.register('Persona',views.PersonaViewSet)
router.register('Proveedor',views.ProveedorViewSet)
router.register('Cliente',views.ClienteViewSet)
router.register('Venta',views.VentaViewSet)
router.register('Categoria',views.CategoriaViewSet)
router.register('Producto',views.ProductoViewSet)
router.register('Detalles',views.DetallesVentaViewSet)
router.register('Compra',views.CompraViewSet)
router.register('Producto',views.ProductoCompraViewSet)
router.register('Presentacion',views.PresentacionViewSet)
router.register('ProductoCompra',views.ProductoCompraViewSet)
router.register('ProductoPresentacion',views.ProductoPresentacionViewSet)
router.register('Rol',views.RolViewSet)
router.register('Usuario',views.UsuarioViewSet)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('AltoqP/',include(router.urls))
]
